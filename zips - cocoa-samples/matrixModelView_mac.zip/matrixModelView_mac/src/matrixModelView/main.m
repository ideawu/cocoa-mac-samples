//
// main.m
// ======
// matrixModelView
//
//  AUTHOR: Song Ho Ahn (song.ahn@gmail.com)
// CREATED: 2012-04-17
// UPDATED: 2012-04-17
//
// Copyright (c) 2012 Song Ho Ahn. All rights reserved.
///////////////////////////////////////////////////////////////////////////////

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
