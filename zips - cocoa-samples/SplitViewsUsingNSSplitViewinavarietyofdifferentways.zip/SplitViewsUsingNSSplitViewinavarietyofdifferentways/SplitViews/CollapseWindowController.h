/*
 Copyright (C) 2015 Apple Inc. All Rights Reserved.
  See LICENSE.txt for this sample’s licensing information
  
  Abstract:
  The NSWindowController subclass managing the collapsible split views. 
 */

@import Cocoa;

@interface CollapseWindowController : NSWindowController

@end
