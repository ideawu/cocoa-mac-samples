/*
 Copyright (C) 2015 Apple Inc. All Rights Reserved.
  See LICENSE.txt for this sample’s licensing information
  
  Abstract:
  The application's delegate for managing its windows. 
 */

@import Cocoa;

@interface AppDelegate : NSObject <NSApplicationDelegate>

@end
