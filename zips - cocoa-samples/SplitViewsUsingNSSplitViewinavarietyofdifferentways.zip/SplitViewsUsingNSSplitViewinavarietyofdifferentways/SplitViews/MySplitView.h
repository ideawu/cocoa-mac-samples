/*
 Copyright (C) 2015 Apple Inc. All Rights Reserved.
  See LICENSE.txt for this sample’s licensing information
  
  Abstract:
  Cust NSSplitView for drawing a custom divider. 
 */

#import <Cocoa/Cocoa.h>

@interface MySplitView : NSSplitView

@end