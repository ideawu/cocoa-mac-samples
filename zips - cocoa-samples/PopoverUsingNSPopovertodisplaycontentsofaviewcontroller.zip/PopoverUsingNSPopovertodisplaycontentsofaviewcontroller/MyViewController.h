/*
 Copyright (C) 2015 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 NSViewController subclass for managing the main app's content.
 */

@import Cocoa;

@interface MyViewController : NSViewController

@end
