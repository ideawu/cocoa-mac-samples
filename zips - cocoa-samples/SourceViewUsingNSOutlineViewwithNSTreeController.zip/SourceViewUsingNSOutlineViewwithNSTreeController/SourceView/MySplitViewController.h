/*
 Copyright (C) 2018 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller managing our split view interface.
 */

@interface MySplitViewController : NSSplitViewController

@end
