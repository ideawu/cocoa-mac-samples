/*
 Copyright (C) 2018 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Custom view to draw a separator.
 */

@interface SeparatorView : NSView

@end
