/*
 Copyright (C) 2018 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Custom NSBox subclass for changing mouse down behavior.
 */

extern NSString *KEY_NAME;
extern NSString *KEY_ICON;

@interface IconViewBox : NSBox

@end
