/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 This is the boiler plate app delegate.
 */

@import Cocoa;

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end
