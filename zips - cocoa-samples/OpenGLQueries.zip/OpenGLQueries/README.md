# OpenGL Queries

Demonstrates how to use OpenGL to query for features and display the results in an outline view.

## Requirements

### Build

EL Capitan (OS X 10.11) and Xcode 7.1

### Runtime

EL Capitan (OS X 10.11)

Copyright (C) 2015 Apple Inc. All rights reserved.
